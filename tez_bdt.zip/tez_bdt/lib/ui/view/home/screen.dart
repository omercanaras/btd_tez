import 'package:flutter/material.dart';

class DenemePage extends StatefulWidget {
  @override
  _DenemePageState createState() => _DenemePageState();
}

class _DenemePageState extends State<DenemePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.blueAccent,

      
    );
  }
}